package uz.xsoft.noteapp.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    private val _selectNotePageLiveData =MutableLiveData<Unit>()
    val selectNotePageLiveData : LiveData<Unit> get() = _selectNotePageLiveData
    private val _selectCheckListPageLiveData =MutableLiveData<Unit>()
    val selectCheckListPageLiveData : LiveData<Unit> get() = _selectCheckListPageLiveData
    private var position = 0

    fun changePagePos(pos: Int) {
        if (pos == position) return
        if (pos == 0) _selectNotePageLiveData.value = Unit
        else _selectCheckListPageLiveData.value = Unit
        position = pos
    }
}