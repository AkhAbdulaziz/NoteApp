package uz.xsoft.noteapp.data.dao

import androidx.room.Dao
import androidx.room.Query
import uz.xsoft.noteapp.data.entity.NoteEntity

@Dao
interface NoteDao : BaseDao<NoteEntity> {

    @Query("SELECT * FROM NoteEntity")
    fun getAllNotes(): List<NoteEntity>

}