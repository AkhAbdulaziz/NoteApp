package uz.xsoft.noteapp.data

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import uz.xsoft.noteapp.app.App
import uz.xsoft.noteapp.data.dao.CheckListDao
import uz.xsoft.noteapp.data.dao.NoteDao
import uz.xsoft.noteapp.data.entity.CheckListEntity
import uz.xsoft.noteapp.data.entity.NoteEntity

@Database(entities = [NoteEntity::class,CheckListEntity::class],version = 2)
abstract class AppDatabase : RoomDatabase() {
    abstract fun getNoteDao() : NoteDao
    abstract fun getCheckListDao() : CheckListDao

    companion object {
        private lateinit var database : AppDatabase

        fun getDatabase() : AppDatabase {
            if (!::database.isInitialized) {
                database = Room.databaseBuilder(App.instance,AppDatabase::class.java,"NoteApp.db")
                    .allowMainThreadQueries()
                    .build()
            }
            return database
        }
    }
}