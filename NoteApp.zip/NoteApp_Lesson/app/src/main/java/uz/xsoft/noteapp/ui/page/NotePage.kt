package uz.xsoft.noteapp.ui.page

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import timber.log.Timber
import uz.xsoft.noteapp.R
import uz.xsoft.noteapp.data.entity.NoteEntity
import uz.xsoft.noteapp.databinding.PageNoteBinding
import uz.xsoft.noteapp.ui.adapter.NoteAdapter
import uz.xsoft.noteapp.ui.viewmodel.NoteViewModel

class NotePage : Fragment(R.layout.page_note) {
    private var _binding: PageNoteBinding? = null
    private val binding get() = _binding!!
    private val viewModel : NoteViewModel by viewModels()
    private val adapter by lazy { NoteAdapter() }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = PageNoteBinding.bind(view)
        binding.noteList.adapter = adapter
        binding.noteList.layoutManager = LinearLayoutManager(requireContext())

        Timber.tag("TTT").d("NotePage")
        viewModel.loadData()
        viewModel.noteListLiveData.observe(viewLifecycleOwner,noteListObserver)
    }

    private val noteListObserver = Observer<List<NoteEntity>>{
        adapter.submitList(it)
        adapter.notifyDataSetChanged()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Timber.tag("TTT").d("NotePage onDestroyView")
        _binding = null
    }

}