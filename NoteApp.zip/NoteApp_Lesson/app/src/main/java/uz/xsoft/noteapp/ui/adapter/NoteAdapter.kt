package uz.xsoft.noteapp.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import uz.xsoft.noteapp.R
import uz.xsoft.noteapp.data.entity.NoteEntity

class NoteAdapter : ListAdapter<NoteEntity, NoteAdapter.NoteViewHolder>(DiffItem) {

    object DiffItem : DiffUtil.ItemCallback<NoteEntity>() {
        override fun areItemsTheSame(oldItem: NoteEntity, newItem: NoteEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: NoteEntity, newItem: NoteEntity): Boolean {
            return oldItem.isPinned == newItem.isPinned ||
                    oldItem.title == newItem.title ||
                    oldItem.message == newItem.message ||
                    oldItem.time == newItem.time
        }
    }

    inner class NoteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val title: TextView = itemView.findViewById(R.id.textTitle)
        private val pinImage: ImageView = itemView.findViewById(R.id.buttonImage)
        fun bind() {
            val data = getItem(adapterPosition)
            title.text = data.title
            if (data.isPinned) pinImage.visibility = View.VISIBLE
            else pinImage.visibility = View.GONE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        NoteViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_note, parent, false))

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        holder.bind()
    }
}