package uz.xsoft.noteapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import uz.xsoft.noteapp.data.AppDatabase
import uz.xsoft.noteapp.data.entity.CheckListEntity

class AddCheckListViewModel : ViewModel() {
    private val database = AppDatabase.getDatabase().getCheckListDao()

    fun addCheckList(data: CheckListEntity) {
        database.insert(data)
    }
}


