package uz.xsoft.noteapp.ui.screen

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import uz.xsoft.noteapp.R
import uz.xsoft.noteapp.data.entity.NoteEntity
import uz.xsoft.noteapp.databinding.ScreenAddNoteBinding
import uz.xsoft.noteapp.ui.viewmodel.AddNoteViewModel

class AddNoteScreen : Fragment() {
    private var _binding: ScreenAddNoteBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AddNoteViewModel by viewModels()
    private var isPinned = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = ScreenAddNoteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.editor.setPadding(10, 10, 10, 10)
        binding.editor.setPlaceholder("Insert note text here...")
        binding.editor.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.colorBackground))

        binding.buttonTextStyleBold.setOnClickListener {
            binding.editor.setBold()
        }

        binding.buttonTextStyleItalic.setOnClickListener {
            binding.editor.setItalic()
        }

        binding.buttonTextStyleunderline.setOnClickListener {
            binding.editor.setUnderline()
        }

        binding.buttonPin.setOnClickListener {
            isPinned =!isPinned
        }
        binding.buttonSave.setOnClickListener {
            viewModel.addNote(
                NoteEntity(
                    0,
                    binding.editTitle.text.toString(),
                    binding.editor.html,
                    System.currentTimeMillis(),
                    isPinned
                )
            )
            findNavController().popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}