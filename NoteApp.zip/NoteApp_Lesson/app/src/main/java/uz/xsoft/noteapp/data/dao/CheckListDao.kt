package uz.xsoft.noteapp.data.dao

import androidx.room.Dao
import androidx.room.Query
import uz.xsoft.noteapp.data.entity.CheckListEntity

@Dao
interface CheckListDao : BaseDao<CheckListEntity> {

    @Query("SELECT * FROM CheckListEntity")
    fun getAllNotes(): List<CheckListEntity>

}