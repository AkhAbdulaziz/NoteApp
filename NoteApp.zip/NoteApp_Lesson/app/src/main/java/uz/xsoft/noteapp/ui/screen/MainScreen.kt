package uz.xsoft.noteapp.ui.screen

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.viewpager2.widget.ViewPager2
import timber.log.Timber
import uz.xsoft.noteapp.R
import uz.xsoft.noteapp.databinding.ScreenMainBinding
import uz.xsoft.noteapp.ui.adapter.MainPageAdapter
import uz.xsoft.noteapp.ui.viewmodel.MainViewModel

class MainScreen : Fragment(R.layout.screen_main) {
    private var _binding: ScreenMainBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = ScreenMainBinding.bind(view)
        val adapter = MainPageAdapter(childFragmentManager, lifecycle)
        binding.pager.adapter = adapter
        binding.pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                viewModel.changePagePos(position)
            }
        })

        binding.bottomNavView.setOnItemSelectedListener {
            if (it.itemId == R.id.notePage) viewModel.changePagePos(0)
            else viewModel.changePagePos(1)
            return@setOnItemSelectedListener true
        }
        binding.buttonAdd.setOnClickListener {
            if (binding.pager.currentItem == 0)
                findNavController().navigate(R.id.action_mainScreen_to_addNoteScreen)
            else findNavController().navigate(R.id.action_mainScreen_to_addCheckListScreen)
        }

        viewModel.selectNotePageLiveData.observe(viewLifecycleOwner, selectNotePageObserver)
        viewModel.selectCheckListPageLiveData.observe(
            viewLifecycleOwner,
            selectCheckListPageObserver
        )
    }

    private val selectNotePageObserver = Observer<Unit> {
        binding.pager.currentItem = 0
        binding.bottomNavView.selectedItemId = R.id.notePage
    }
    private val selectCheckListPageObserver = Observer<Unit> {
        binding.pager.currentItem = 1
        binding.bottomNavView.selectedItemId = R.id.checkList
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Timber.tag("TTT").d("MainScreen onDestroyView")
        _binding = null
    }
}